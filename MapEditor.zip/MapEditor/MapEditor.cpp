﻿#include <windows.h>
#include <windowsx.h>
#include <gdiplus.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>

#pragma comment(lib, "gdiplus.lib")
using namespace Gdiplus;


//==============================================================
// 定数定義
//==============================================================

// 1タイルの大きさ（ピクセル）
const int TILE = 32;

// マップのタイル数（横・縦）
// 40×40 タイル → 全体サイズは 1280×1280 ピクセル
const int MAP_WIDTH = 40;
const int MAP_HEIGHT = 40;

// マップ全体のピクセルサイズ
const int MAP_PIX_W = MAP_WIDTH * TILE; // 40 * 32 = 1280
const int MAP_PIX_H = MAP_HEIGHT * TILE; // 40 * 32 = 1280

// マップ表示ウィンドウの「見える範囲」（ビュー）のサイズ
// ここでは 640×640 の範囲だけを表示し、スクロールバーで移動する
const int VIEW_W = 640;  // 20タイル分
const int VIEW_H = 640;  // 20タイル分

// タイルセット（パレット）の設定
// tileset.bmp は 32×32 のタイルが 16×16 並んでいる想定（計 256タイル）
const int TILE_PER_ROW = 16;
const int TILE_PER_COL = 16;
const int TOTAL_TILES = TILE_PER_ROW * TILE_PER_COL;

// パレットウィンドウのサイズ（タイルシート全体を表示）
const int PALETTE_W = TILE * TILE_PER_ROW; // 32 * 16 = 512
const int PALETTE_H = TILE * TILE_PER_COL; // 32 * 16 = 512

// メニューID（コマンド識別用）
const int ID_MENU_SAVE_CSV = 1; // CSV保存
const int ID_MENU_LOAD_CSV = 2; // CSV読込
const int ID_MENU_EXPORT_ARR = 3; // C配列書き出し
const int ID_MENU_LOAD_TILESET = 4; // タイルセット読み込み

//==============================================================
// グローバル変数
//==============================================================

// GDI+ 用トークン
ULONG_PTR gdiToken;

// タイルセット画像（BMP）
// Image* は GDI+ の画像クラス
Image* imgTiles = nullptr;

// マップデータ本体
// mapData[y * MAP_WIDTH + x] でアクセスする
// 値はタイルID（0〜255想定）、-1 は「何も置いていない」xz

std::vector<int> mapData(MAP_WIDTH* MAP_HEIGHT, -1); // ワーニング出るのが気持ち悪いけどコンパイラの問題らしい



// 現在パレットで選択されているタイル番号
int selectedTile = 0;

// マウスドラッグ中かどうか
bool dragging = false;
// 消しゴムモードかどうか（右ドラッグ中）
bool eraseMode = false;

// ウィンドウハンドル
HWND hWndMap = nullptr; // マップ表示ウィンドウ
HWND hWndPalette = nullptr; // パレットウィンドウ

// マップのスクロール位置（ピクセル単位）
// scrollX, scrollY が増えると「画面が右下に移動」したように見える
int scrollX = 0;
int scrollY = 0;

//==============================================================
// スクロールバーの設定更新
//   マップの大きさとビューサイズに応じて、スクロール範囲を設定する
//==============================================================
void UpdateScrollBars(HWND hWnd)
{
    RECT rc;
    GetClientRect(hWnd, &rc);
    int clientW = rc.right - rc.left;
    int clientH = rc.bottom - rc.top;

    // ------------------------------
    // 水平スクロールバー（横方向）
    // ------------------------------
    SCROLLINFO si = {};
    si.cbSize = sizeof(si);
    si.fMask = SIF_RANGE | SIF_PAGE | SIF_POS;
    si.nMin = 0;
    si.nMax = MAP_PIX_W - 1; // 全体の最大値（ピクセル）
    si.nPage = clientW;       // 1ページ分（ビューの幅）
    si.nPos = scrollX;       // 現在位置
    SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);

    // ------------------------------
    // 垂直スクロールバー（縦方向）
    // ------------------------------
    si.nMin = 0;
    si.nMax = MAP_PIX_H - 1;
    si.nPage = clientH;
    si.nPos = scrollY;
    SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
}

//==============================================================
// マップ描画処理
//   ・scrollX / scrollY に応じて、表示する範囲を切り替える
//   ・画面上には VIEW_W×VIEW_H ぶんの範囲だけ描画
//==============================================================
void DrawMap(HWND hWnd, HDC hdc)
{
    Graphics g(hdc);

    RECT rc;
    GetClientRect(hWnd, &rc);
    int clientW = rc.right - rc.left;
    int clientH = rc.bottom - rc.top;

    // 背景をグレーで塗りつぶし
    g.Clear(Color(60, 60, 60));

    // ------------------------------
    // どのタイルから描画を始めるか計算
    // ------------------------------
    // スクロール位置から描画開始タイルを求める
    int startTileX = scrollX / TILE;
    int startTileY = scrollY / TILE;

    // タイルの先頭が画面のどこから始まるか（余り分をオフセットとする）
    int offsetX = -(scrollX % TILE);
    int offsetY = -(scrollY % TILE);

    // 画面に必要なタイル枚数（はみ出し分 +2 して余裕を持たせる）
    int tilesX = clientW / TILE + 2;
    int tilesY = clientH / TILE + 2;

    // ------------------------------
    // 実際に描画
    // ------------------------------
    for (int ty = 0; ty < tilesY; ++ty)
    {
        int mapY = startTileY + ty; // 実際のマップ上のY
        if (mapY < 0 || mapY >= MAP_HEIGHT) continue;

        for (int tx = 0; tx < tilesX; ++tx)
        {
            int mapX = startTileX + tx; // 実際のマップ上のX
            if (mapX < 0 || mapX >= MAP_WIDTH) continue;

            // マップ配列上のインデックス
            int idx = mapY * MAP_WIDTH + mapX;
            int tileId = mapData[idx];

            // 画面上の描画位置
            int dstX = offsetX + tx * TILE;
            int dstY = offsetY + ty * TILE;

            // タイルが -1 でなければ描画
            if (tileId >= 0 && imgTiles)
            {
                // タイルシート上の切り出し位置
                int sx = (tileId % TILE_PER_ROW) * TILE;
                int sy = (tileId / TILE_PER_ROW) * TILE;

                g.DrawImage(
                    imgTiles,
                    RectF((REAL)dstX, (REAL)dstY, (REAL)TILE, (REAL)TILE),
                    (REAL)sx, (REAL)sy, (REAL)TILE, (REAL)TILE,
                    UnitPixel
                );
            }

            // グリッド線（タイルの枠）
            Pen gridPen(Color(40, 40, 40), 1);
            g.DrawRectangle(&gridPen, dstX, dstY, TILE, TILE);
        }
    }
}

//==============================================================
// パレット（タイル一覧）の描画処理
//==============================================================
void DrawPalette(HWND hWnd, HDC hdc)
{
    Graphics g(hdc);

    RECT rc;
    GetClientRect(hWnd, &rc);
    int clientW = rc.right - rc.left;
    int clientH = rc.bottom - rc.top;

    int tilesX = clientW / TILE + 1;
    int tilesY = clientH / TILE + 1;

    // 背景を少し暗めに
    g.Clear(Color(30, 30, 30));

    for (int y = 0; y < tilesY; ++y)
    {
        for (int x = 0; x < tilesX; ++x)
        {
            // タイルID（0〜TOTAL_TILES-1）
            int tileId = y * TILE_PER_ROW + x;
            if (tileId < 0 || tileId >= TOTAL_TILES) continue;

            if (imgTiles)
            {
                // タイルシート上の位置
                int sx = (tileId % TILE_PER_ROW) * TILE;
                int sy = (tileId / TILE_PER_ROW) * TILE;

                g.DrawImage(
                    imgTiles,
                    RectF((REAL)(x * TILE), (REAL)(y * TILE), (REAL)TILE, (REAL)TILE),
                    (REAL)sx, (REAL)sy, (REAL)TILE, (REAL)TILE, UnitPixel
                );
            }

            // 枠（グリッド）
            Pen gridPen(Color(60, 60, 60), 1);
            g.DrawRectangle(&gridPen, x * TILE, y * TILE, TILE, TILE);

            // 選択中のタイルの場合、黄色枠で強調
            if (tileId == selectedTile)
            {
                Pen pen(Color(255, 255, 0), 2);
                g.DrawRectangle(&pen, x * TILE, y * TILE, TILE, TILE);
            }
        }
    }
}

//==============================================================
// マップ保存（CSV形式）
//==============================================================
void SaveMapCSV(HWND hwnd)
{
    OPENFILENAMEW ofn = {};
    wchar_t szFile[MAX_PATH] = L"map.csv";

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"CSV Files\0*.csv\0";
    ofn.Flags = OFN_OVERWRITEPROMPT;

    if (!GetSaveFileNameW(&ofn)) return;

    std::wofstream ofs(szFile);
    if (!ofs) return;

    for (int y = 0; y < MAP_HEIGHT; ++y)
    {
        for (int x = 0; x < MAP_WIDTH; ++x)
        {
            ofs << mapData[y * MAP_WIDTH + x];
            if (x < MAP_WIDTH - 1)
                ofs << L",";    // 区切り
        }
        ofs << L"\n";
    }
}

//==============================================================
// マップ読み込み（CSV形式）
//==============================================================
void LoadMapCSV(HWND hwnd)
{
    OPENFILENAMEW ofn = {};
    wchar_t szFile[MAX_PATH] = L"";

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"CSV Files\0*.csv\0";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

    if (!GetOpenFileNameW(&ofn)) return;

    std::wifstream ifs(szFile);
    if (!ifs) return;

    // いったん全部クリア
    mapData.assign(MAP_WIDTH * MAP_HEIGHT, -1);

    std::wstring line;
    int y = 0;
    while (std::getline(ifs, line) && y < MAP_HEIGHT)
    {
        std::wstringstream wss(line);
        for (int x = 0; x < MAP_WIDTH; ++x)
        {
            int val;
            if (!(wss >> val))
                val = -1;

            mapData[y * MAP_WIDTH + x] = val;

            // カンマを飛ばす
            if (wss.peek() == L',')
                wss.ignore();
        }
        ++y;
    }

    InvalidateRect(hwnd, NULL, TRUE);
}

//==============================================================
// C配列形式で出力
//   形式：
//   {0,0,0,...},
//   {0,0,0,...},
//   ...
//==============================================================
void ExportMapArray(HWND hwnd)
{
    OPENFILENAMEW ofn = {};
    wchar_t szFile[MAX_PATH] = L"map_array.txt";

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"Text Files\0*.txt\0All Files\0*.*\0";
    ofn.Flags = OFN_OVERWRITEPROMPT;

    if (!GetSaveFileNameW(&ofn)) return;

    std::wofstream ofs(szFile);
    if (!ofs) return;

    // ここでは int mapData[40][40] の中身だけを出力するイメージ
    // （実際のファイルには配列名は書かず、中身だけ書き出し）
    for (int y = 0; y < MAP_HEIGHT; ++y)
    {
        ofs << L"{";
        for (int x = 0; x < MAP_WIDTH; ++x)
        {
            ofs << mapData[y * MAP_WIDTH + x];
            if (x < MAP_WIDTH - 1)
                ofs << L",";
        }
        ofs << L"}";
        if (y < MAP_HEIGHT - 1)
            ofs << L",";
        ofs << L"\n";
    }
}

//==============================================================
// タイルセット（BMP）をファイルから読み込む
//   メニュー「Load Tileset」から呼び出す
//==============================================================
void LoadTileset(HWND hwnd)
{
    OPENFILENAMEW ofn = {};
    wchar_t szFile[MAX_PATH] = L"tileset.bmp";

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"Bitmap Files\0*.bmp\0All Files\0*.*\0";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

    if (!GetOpenFileNameW(&ofn))
        return;

    // 以前の画像を削除
    delete imgTiles;
    imgTiles = nullptr;

    // 新しいBMPを読み込み
    imgTiles = new Image(szFile);
    if (imgTiles->GetLastStatus() != Ok)
    {
        MessageBox(hwnd, L"タイルセットの読み込みに失敗しました", L"Error", MB_OK | MB_ICONERROR);
        delete imgTiles;
        imgTiles = nullptr;
        return;
    }

    // パレット・マップを再描画
    InvalidateRect(hWndPalette, NULL, TRUE);
    InvalidateRect(hWndMap, NULL, TRUE);
}

//==============================================================
// マップウィンドウのウィンドウプロシージャ
//==============================================================
LRESULT CALLBACK MapWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_SIZE:
        // クライアントサイズが変わったらスクロールバーを更新
        UpdateScrollBars(hWnd);
        return 0;

        // ------------------------------
        // 水平スクロールバー操作
        // ------------------------------
    case WM_HSCROLL:
    {
        SCROLLINFO si = {};
        si.cbSize = sizeof(si);
        si.fMask = SIF_ALL;
        GetScrollInfo(hWnd, SB_HORZ, &si);

        int oldPos = si.nPos;

        switch (LOWORD(wParam))
        {
        case SB_LINELEFT:   si.nPos -= TILE;      break; // ←キー1回分
        case SB_LINERIGHT:  si.nPos += TILE;      break; // →キー1回分
        case SB_PAGELEFT:   si.nPos -= si.nPage;  break; // PageUp
        case SB_PAGERIGHT:  si.nPos += si.nPage;  break; // PageDown
        case SB_THUMBTRACK: si.nPos = si.nTrackPos; break; // つまみドラッグ
        default: break;
        }

        // 範囲チェック
        if (si.nPos < si.nMin) si.nPos = si.nMin;
        if (si.nPos > si.nMax - (int)si.nPage + 1)
            si.nPos = si.nMax - si.nPage + 1;

        si.fMask = SIF_POS;
        SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
        GetScrollInfo(hWnd, SB_HORZ, &si);

        // 位置が変わったら再描画
        if (si.nPos != oldPos)
        {
            scrollX = si.nPos;
            InvalidateRect(hWnd, NULL, FALSE); // スクロール時は全体再描画でOK
        }
        return 0;
    }

    // ------------------------------
    // 垂直スクロールバー操作
    // ------------------------------
    case WM_VSCROLL:
    {
        SCROLLINFO si = {};
        si.cbSize = sizeof(si);
        si.fMask = SIF_ALL;
        GetScrollInfo(hWnd, SB_VERT, &si);

        int oldPos = si.nPos;

        switch (LOWORD(wParam))
        {
        case SB_LINEUP:     si.nPos -= TILE;     break; // ↑キー
        case SB_LINEDOWN:   si.nPos += TILE;     break; // ↓キー
        case SB_PAGEUP:     si.nPos -= si.nPage; break;
        case SB_PAGEDOWN:   si.nPos += si.nPage; break;
        case SB_THUMBTRACK: si.nPos = si.nTrackPos; break;
        default: break;
        }

        if (si.nPos < si.nMin) si.nPos = si.nMin;
        if (si.nPos > si.nMax - (int)si.nPage + 1)
            si.nPos = si.nMax - si.nPage + 1;

        si.fMask = SIF_POS;
        SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
        GetScrollInfo(hWnd, SB_VERT, &si);

        if (si.nPos != oldPos)
        {
            scrollY = si.nPos;
            InvalidateRect(hWnd, NULL, FALSE); // スクロール時は全体再描画
        }
        return 0;
    }

    // ------------------------------
    // 再描画
    // ------------------------------
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        DrawMap(hWnd, hdc);
        EndPaint(hWnd, &ps);
        return 0;
    }

    // ------------------------------
    // 左ボタンダウン：描画開始
    // 右ボタンダウン：消しゴム開始
    // ------------------------------
    case WM_LBUTTONDOWN:
    case WM_RBUTTONDOWN:
    {
        SetCapture(hWnd);          // ドラッグをウィンドウ内に限定
        dragging = true;
        eraseMode = (msg == WM_RBUTTONDOWN);

        int mx = GET_X_LPARAM(lParam);
        int my = GET_Y_LPARAM(lParam);

        // 画面座標 → マップ座標に変換
        int mapX = (scrollX + mx) / TILE;
        int mapY = (scrollY + my) / TILE;

        if (mapX >= 0 && mapX < MAP_WIDTH &&
            mapY >= 0 && mapY < MAP_HEIGHT)
        {
            int idx = mapY * MAP_WIDTH + mapX;
            mapData[idx] = eraseMode ? -1 : selectedTile;

            // 部分再描画：そのセルだけを再描画
            RECT dirty;
            dirty.left = mapX * TILE - scrollX;
            dirty.top = mapY * TILE - scrollY;
            dirty.right = dirty.left + TILE;
            dirty.bottom = dirty.top + TILE;
            InvalidateRect(hWnd, &dirty, FALSE);
        }
        return 0;
    }

    // ------------------------------
    // マウス移動中（ドラッグペイント）
    // ------------------------------
    case WM_MOUSEMOVE:
        if (dragging)
        {
            int mx = GET_X_LPARAM(lParam);
            int my = GET_Y_LPARAM(lParam);

            int mapX = (scrollX + mx) / TILE;
            int mapY = (scrollY + my) / TILE;

            if (mapX >= 0 && mapX < MAP_WIDTH &&
                mapY >= 0 && mapY < MAP_HEIGHT)
            {
                int idx = mapY * MAP_WIDTH + mapX;
                int newVal = eraseMode ? -1 : selectedTile;

                if (mapData[idx] != newVal)
                {
                    mapData[idx] = newVal;

                    // ここも部分再描画
                    RECT dirty;
                    dirty.left = mapX * TILE - scrollX;
                    dirty.top = mapY * TILE - scrollY;
                    dirty.right = dirty.left + TILE;
                    dirty.bottom = dirty.top + TILE;
                    InvalidateRect(hWnd, &dirty, FALSE);
                }
            }
        }
        return 0;

        // ------------------------------
        // ボタンアップ：ドラッグ終了
        // ------------------------------
    case WM_LBUTTONUP:
    case WM_RBUTTONUP:
        dragging = false;
        ReleaseCapture();
        return 0;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

//==============================================================
// パレットウィンドウのウィンドウプロシージャ
//==============================================================
LRESULT CALLBACK PaletteWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        DrawPalette(hWnd, hdc);
        EndPaint(hWnd, &ps);
        return 0;
    }

    case WM_LBUTTONDOWN:
    {
        // クリックした位置のタイルIDを選択中タイルにする
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);

        int tx = x / TILE;
        int ty = y / TILE;

        int id = ty * TILE_PER_ROW + tx;
        if (id >= 0 && id < TOTAL_TILES)
        {
            selectedTile = id;
            InvalidateRect(hWnd, NULL, FALSE);
        }
        return 0;
    }
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

//==============================================================
// WinMain（エントリポイント）
//==============================================================
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR, int)
{
    // ------------------------------
    // GDI+ 初期化
    // ------------------------------
    GdiplusStartupInput gsi;
    GdiplusStartup(&gdiToken, &gsi, NULL);

    // デフォルトの tileset 読み込み（失敗しても動作はする）
    imgTiles = new Image(L"res\\tileset.bmp");
    if (imgTiles->GetLastStatus() != Ok)
    {
        MessageBox(NULL, L"res\\tileset.bmp の読み込みに失敗しました。\nメニューから Load Tileset で選択してください。", L"Warning", MB_OK | MB_ICONWARNING);
        delete imgTiles;
        imgTiles = nullptr;
    }

    // ------------------------------
    // マップウィンドウクラス登録
    // ------------------------------
    WNDCLASS wc = {};
    wc.lpfnWndProc = MapWndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"MapEditorMain";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClass(&wc);

    // ------------------------------
    // パレットウィンドウクラス登録
    // ------------------------------
    WNDCLASS pc = {};
    pc.lpfnWndProc = PaletteWndProc;
    pc.hInstance = hInstance;
    pc.lpszClassName = L"MapEditorPalette";
    pc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClass(&pc);

    // ------------------------------
    // マップウィンドウ作成（スクロールバー付き）
    // ------------------------------
    RECT rc = { 0,0, VIEW_W, VIEW_H };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW | WS_HSCROLL | WS_VSCROLL, TRUE);

    hWndMap = CreateWindow(
        L"MapEditorMain",
        L"Map Editor",
        WS_OVERLAPPEDWINDOW | WS_HSCROLL | WS_VSCROLL,
        50, 50,
        rc.right - rc.left,
        rc.bottom - rc.top,
        NULL, NULL, hInstance, NULL
    );

    ShowWindow(hWndMap, SW_SHOW);

    // ------------------------------
    // パレットウィンドウ作成
    // ------------------------------
    RECT rcP = { 0,0, PALETTE_W, PALETTE_H };
    AdjustWindowRect(&rcP, WS_OVERLAPPEDWINDOW, TRUE);

    hWndPalette = CreateWindow(
        L"MapEditorPalette",
        L"Palette",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,  // ★リサイズ禁止
        80 + (rc.right - rc.left), 50,
        rcP.right - rcP.left,
        rcP.bottom - rcP.top,
        NULL, NULL, hInstance, NULL
    );


    ShowWindow(hWndPalette, SW_SHOW);

    // ------------------------------
    // メニュー作成（CSV保存/読込・配列書き出し・タイルセット読込）
    // ------------------------------
    HMENU hMenu = CreateMenu();
    AppendMenuW(hMenu, MF_STRING, ID_MENU_SAVE_CSV, L"Save CSV");
    AppendMenuW(hMenu, MF_STRING, ID_MENU_LOAD_CSV, L"Load CSV");
    AppendMenuW(hMenu, MF_STRING, ID_MENU_EXPORT_ARR, L"Export C Array");
    AppendMenuW(hMenu, MF_STRING, ID_MENU_LOAD_TILESET, L"Load Tileset (BMP)");
    SetMenu(hWndMap, hMenu);

    // 初回スクロールバー設定
    UpdateScrollBars(hWndMap);

    // ------------------------------
    // メッセージループ
    // ------------------------------
    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0))
    {
        if (msg.message == WM_COMMAND)
        {
            switch (LOWORD(msg.wParam))
            {
            case ID_MENU_SAVE_CSV:
                SaveMapCSV(hWndMap);
                break;
            case ID_MENU_LOAD_CSV:
                LoadMapCSV(hWndMap);
                break;
            case ID_MENU_EXPORT_ARR:
                ExportMapArray(hWndMap);
                break;
            case ID_MENU_LOAD_TILESET:
                LoadTileset(hWndMap);
                break;
            }
        }

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // ------------------------------
    // 終了処理
    // ------------------------------
    delete imgTiles;
    GdiplusShutdown(gdiToken);

    return 0;
}
