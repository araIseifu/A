﻿#include <windows.h>
#include <gdiplus.h>
#include <fstream>
#include <sstream>
#include <string>

using namespace Gdiplus;

#pragma comment(lib, "gdiplus.lib")

#define DEBUG 0

//=============================================
// 定数
//=============================================
const int TILE = 32;
const int MAP_W = 40;
const int MAP_H = 40;

const int PLAYER_W = 32;
const int PLAYER_H = 32;

const int TILESET_W = 16;
const int TILESET_H = 16;
const int TILE_COUNT = TILESET_W * TILESET_H;

// 外側に表示する余白タイル数（上下左右 4 タイル分）
const int MAP_MARGIN = 4;
// 余白部分に使うタイルID
const int OUT_TILE = 48;

//=============================================
// グローバル
//=============================================
ULONG_PTR gdiToken;

Image* imgPlayer = nullptr;
HBITMAP hTileset = NULL;
HDC     hTilesetDC = NULL;

HBITMAP backBuffer = NULL;
HDC backDC = NULL;

int mapData[MAP_H][MAP_W];

int screenW = TILE * 15;
int screenH = TILE * 9;

// カメラオフセット（仮想マップ座標系での左上ピクセル）
int mapOffsetX = 0;
int mapOffsetY = 0;

// プレイヤーのワールド座標（内部マップ上のピクセル位置）
int playerWorldX;
int playerWorldY;

// タイル単位移動用
bool isMoving = false;
int moveDX = 0;
int moveDY = 0;
int moveRemaining = 0; // 残り移動ピクセル数

int playerDir = 3; // 0:下 1:左 2:右 3:上

bool keyUp = false, keyDown = false, keyLeft = false, keyRight = false;

int animLoop[8] = { 0,1,2,1,0,1,2,1 };
int animIndex = 0;
int animTimer = 0;

#if DEBUG
int debugCheckX = -1; // 衝突チェックしているタイルX（タイル座標）
int debugCheckY = -1; // 衝突チェックしているタイルY
#endif

//=============================================
// マップ初期化
//=============================================
void InitMap() {
    int temp[MAP_H][MAP_W] = {
        { 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 },
        { 48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,128,130,131,131,131,132,133,49,48,48,48,48,48,48,48,128,130,130,130,130,130,133,49,128,131,133,53,51,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,129,50,51,48,51,51,48,51,48,129,1,0,0,0,0,129,50,129,0,134,53,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,129,50,48,48,48,48,48,48,48,129,1,0,0,0,0,129,50,140,97,137,50,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,103,0,0,140,131,131,137,23,24,140,131,131,137,1,0,103,0,0,129,50,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,129,50,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,128,130,131,131,160,161,131,131,132,133,1,0,0,0,0,129,50,48,48,48,48,48,48,48,48,48,48,48 },
        { 48,48,48,48,48,128,138,131,131,132,133,1,129,1,0,0,0,0,0,0,0,135,130,131,102,131,131,141,131,137,23,130,132,133,49,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,0,129,1,129,1,0,0,16,17,0,240,0,129,1,0,0,0,0,0,0,0,0,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,96,97,0,139,1,129,1,0,0,32,33,0,0,0,129,1,0,0,0,0,0,0,0,0,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,0,0,0,135,130,160,1,0,0,0,161,136,141,130,132,141,176,177,131,130,132,133,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,0,134,1,129,64,65,0,16,17,0,66,67,129,1,0,129,192,193,129,0,0,129,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,135,130,131,131,132,133,1,129,64,65,0,32,33,0,66,67,129,1,0,139,208,209,139,0,0,139,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,98,129,1,129,64,56,0,0,0,0,55,67,129,1,0,0,0,0,0,0,0,0,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,98,129,1,129,50,56,0,16,17,0,55,48,129,1,0,0,0,0,0,0,0,0,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,0,102,1,129,50,72,0,32,33,0,71,48,129,1,0,0,0,0,0,0,0,134,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,129,1,0,0,0,129,1,129,50,0,20,21,21,22,0,55,129,1,0,134,0,0,134,0,0,129,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,136,138,130,131,131,137,1,139,50,0,163,164,164,166,0,71,140,131,131,138,131,132,129,130,131,137,241,132,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,99,100,101,0,0,0,0,0,179,180,181,182,0,0,0,0,0,104,104,104,129,1,0,0,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,0,0,195,196,197,198,0,0,0,0,0,0,0,0,129,15,15,15,15,15,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,48,135,130,137,0,0,140,132,133,1,211,212,213,214,0,129,130,0,0,0,0,0,129,15,15,15,15,15,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,129,1,0,0,0,0,0,129,0,0,0,0,0,0,129,1,0,0,0,0,129,50,48,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,132,133,1,16,17,0,129,130,131,131,131,131,0,0,129,1,0,0,0,0,129,171,55,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,103,0,0,0,0,129,1,32,33,0,129,1,0,0,0,0,0,0,134,130,131,131,131,131,129,169,55,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,0,129,1,0,0,0,129,1,0,0,0,0,0,0,129,170,170,170,170,170,170,169,55,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,103,0,129,1,16,17,0,129,1,0,129,131,131,133,130,134,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,0,129,1,32,33,0,129,1,0,130,1,0,130,1,129,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,0,135,130,0,0,130,129,1,0,0,0,0,194,1,129,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,48,129,1,0,0,0,0,0,0,129,1,0,0,0,129,1,0,133,1,0,133,1,129,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,171,140,131,131,131,131,131,131,131,131,160,25,25,161,138,130,130,130,130,130,130,130,129,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,201,170,170,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,216,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,169,169,201,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,169,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,169,169,201,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,169,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,169,169,201,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,169,169,169,169,169,169,169,169,55,48,48,48,48 },
        { 48,48,48,48,48,169,169,201,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,169,169,169,169,169,169,169,169,55,48,48,48,48 }
    };

    for (int y = 0; y < MAP_H; y++)
        for (int x = 0; x < MAP_W; x++)
            mapData[y][x] = temp[y][x];
}

//=============================================
// JSONから mapData を読み込む
//=============================================
bool LoadMapJSON(const wchar_t* filename)
{
    std::wifstream ifs(filename);
    if (!ifs) return false;

    std::wstring line;
    int y = 0;

    while (std::getline(ifs, line))
    {
        // " [1,2,3]," のような行だけ抜き出す
        size_t p1 = line.find(L"[");
        size_t p2 = line.find(L"]");
        if (p1 == std::wstring::npos || p2 == std::wstring::npos) continue;

        std::wstring inside = line.substr(p1 + 1, p2 - p1 - 1);
        std::wstringstream ss(inside);

        for (int x = 0; x < MAP_W; x++)
        {
            int v;
            ss >> v;
            mapData[y][x] = v;
            if (ss.peek() == L',') ss.ignore();
        }

        y++;
        if (y >= MAP_H) break;
    }

    return true;
}

//=============================================
// 壁判定
//=============================================
bool IsWall(int tx, int ty) {
    if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H)
        return true;

    int id = mapData[ty][tx];
    // 0〜96 → 通行OK, 97以上 → 壁
    return (id > 96);
}

//=============================================
// カメラ制限込みの移動可否判定
// （true のときだけ debug を更新する）
//=============================================
bool CanMoveWithCamera(int dx, int dy)
{
    // 今いるタイル座標
    int tileX = playerWorldX / TILE;
    int tileY = playerWorldY / TILE;

    // 次に行きたいタイル
    int nx = tileX + dx;
    int ny = tileY + dy;

    // まずマップ上の「壁／外かどうか」
    if (IsWall(nx, ny)) {
        return false;
    }

    // 1タイル進んだときのプレイヤーのワールド座標
    int nextWorldX = nx * TILE;
    int nextWorldY = ny * TILE;

    // 仮想マップサイズ
    int VIRTUAL_W = (MAP_W + MAP_MARGIN * 2) * TILE;
    int VIRTUAL_H = (MAP_H + MAP_MARGIN * 2) * TILE;

    // 仮想マップ座標系でのプレイヤー位置
    int nextVirtualX = nextWorldX + MAP_MARGIN * TILE;
    int nextVirtualY = nextWorldY + MAP_MARGIN * TILE;

    // そのときのカメラオフセット（プレイヤー中央基準）
    int nextOffsetX = nextVirtualX - (screenW / 2 - PLAYER_W / 2);
    int nextOffsetY = nextVirtualY - (screenH / 2 - PLAYER_H / 2);

    int maxOffsetX = VIRTUAL_W - screenW;
    int maxOffsetY = VIRTUAL_H - screenH;

    // スクロール限界を超えるなら「進めない」
    if (nextOffsetX < 0 || nextOffsetX > maxOffsetX ||
        nextOffsetY < 0 || nextOffsetY > maxOffsetY)
    {
        return false;
    }

#if DEBUG
    // 実際に「進める」と判断したときだけ、debugCheck を更新
    debugCheckX = nx;
    debugCheckY = ny;
#endif

    return true;
}

//=============================================
// 入力
//=============================================
void UpdateInput() {
    keyUp = (GetAsyncKeyState(VK_UP) & 0x8000);
    keyDown = (GetAsyncKeyState(VK_DOWN) & 0x8000);
    keyLeft = (GetAsyncKeyState(VK_LEFT) & 0x8000);
    keyRight = (GetAsyncKeyState(VK_RIGHT) & 0x8000);
}

//=============================================
// 背景スクロール ＋ プレイヤー移動
// （カメラは「仮想マップ座標系」で制御）
//=============================================
void UpdateScroll() {

    const int speed = 8; // 1フレームあたり 8px、4フレームで1タイル

    // まだ移動していないときだけ、新しい移動を開始
    if (!isMoving) {
        if (keyUp && CanMoveWithCamera(0, -1)) {
            isMoving = true;
            moveDX = 0; moveDY = -1;
            moveRemaining = TILE;
            playerDir = 3;
        }
        else if (keyDown && CanMoveWithCamera(0, 1)) {
            isMoving = true;
            moveDX = 0; moveDY = 1;
            moveRemaining = TILE;
            playerDir = 0;
        }
        else if (keyLeft && CanMoveWithCamera(-1, 0)) {
            isMoving = true;
            moveDX = -1; moveDY = 0;
            moveRemaining = TILE;
            playerDir = 1;
        }
        else if (keyRight && CanMoveWithCamera(1, 0)) {
            isMoving = true;
            moveDX = 1; moveDY = 0;
            moveRemaining = TILE;
            playerDir = 2;
        }
    }

    // 移動中なら、毎フレーム 8px ずつ進める
    if (isMoving) {
        int step = (moveRemaining < speed) ? moveRemaining : speed;
        playerWorldX += moveDX * step;
        playerWorldY += moveDY * step;
        moveRemaining -= step;
        if (moveRemaining <= 0) {
            moveRemaining = 0;
            isMoving = false;
        }
    }

    //=====================================
    // ★ カメラ位置（仮想マップ座標系）
    //=====================================
    // 仮想マップのサイズ（上下左右に MAP_MARGIN 追加したとみなす）
    int VIRTUAL_W = (MAP_W + MAP_MARGIN * 2) * TILE;
    int VIRTUAL_H = (MAP_H + MAP_MARGIN * 2) * TILE;

    // プレイヤーの「仮想マップ座標系」での位置
    int playerVirtualX = playerWorldX + MAP_MARGIN * TILE;
    int playerVirtualY = playerWorldY + MAP_MARGIN * TILE;

    // プレイヤーを画面中央に置くようにカメラを決定
    mapOffsetX = playerVirtualX - (screenW / 2 - PLAYER_W / 2);
    mapOffsetY = playerVirtualY - (screenH / 2 - PLAYER_H / 2);

    // 仮想マップ内にクランプ（0 〜 VIRTUAL_* - 画面）
    int maxOffsetX = VIRTUAL_W - screenW;
    int maxOffsetY = VIRTUAL_H - screenH;

    if (mapOffsetX < 0) mapOffsetX = 0;
    if (mapOffsetY < 0) mapOffsetY = 0;
    if (mapOffsetX > maxOffsetX) mapOffsetX = maxOffsetX;
    if (mapOffsetY > maxOffsetY) mapOffsetY = maxOffsetY;
}

//=============================================
// アニメ
//=============================================
void UpdateAnimation() {
    animTimer++;
    if (animTimer >= 3) {
        animTimer = 0;
        animIndex = (animIndex + 1) % 8;
    }
}

//=============================================
// 描画（仮想マップ＋外周タイル）
//=============================================
void DrawGame(HWND hWnd) {
    HDC hdc = GetDC(hWnd);

    Graphics g(backDC);
    g.Clear(Color(0, 0, 0));

    // 仮想マップ上でのタイル開始位置とピクセルオフセット
    int startTileX = mapOffsetX / TILE;
    int startTileY = mapOffsetY / TILE;

    int startPixelX = -(mapOffsetX % TILE);
    int startPixelY = -(mapOffsetY % TILE);

    // 仮想マップ上のタイルを走査
    for (int yy = 0; yy <= screenH / TILE + 1; yy++) {
        for (int xx = 0; xx <= screenW / TILE + 1; xx++) {
            int mxVirtual = startTileX + xx; // 仮想マップ上のタイルX
            int myVirtual = startTileY + yy; // 仮想マップ上のタイルY

            // 内部マップ座標に変換（MAP_MARGIN 分だけ内側にズラす）
            int mx = mxVirtual - MAP_MARGIN;
            int my = myVirtual - MAP_MARGIN;

            int id;
            if (mx < 0 || my < 0 || mx >= MAP_W || my >= MAP_H)
                id = OUT_TILE;   // 内部マップ外は外周タイル
            else
                id = mapData[my][mx];

            int sx = (id % TILESET_W) * TILE;
            int sy = (id / TILESET_W) * TILE;

            BitBlt(backDC,
                startPixelX + xx * TILE,
                startPixelY + yy * TILE,
                TILE, TILE,
                hTilesetDC,
                sx, sy,
                SRCCOPY);
        }
    }

    // プレイヤー描画（中央固定）
    int playerScreenX = screenW / 2 - PLAYER_W / 2;
    int playerScreenY = screenH / 2 - PLAYER_H / 2;

    int fr = animLoop[animIndex];
    int psx = fr * PLAYER_W;
    int psy = playerDir * PLAYER_H;

    g.DrawImage(imgPlayer,
        Rect(playerScreenX, playerScreenY, PLAYER_W, PLAYER_H),
        psx, psy, PLAYER_W, PLAYER_H,
        UnitPixel);

#if DEBUG
    // プレイヤーが今いるタイルと ID
    int curTileX = playerWorldX / TILE;
    int curTileY = playerWorldY / TILE;
    int curTileID = -1;
    if (curTileX >= 0 && curTileY >= 0 && curTileX < MAP_W && curTileY < MAP_H) {
        curTileID = mapData[curTileY][curTileX];
    }

    WCHAR debugText[128];
    wsprintf(debugText, L"Pos: (%d, %d)  ID: %d", curTileX, curTileY, curTileID);

    FontFamily fontFamily(L"Consolas");
    Font font(&fontFamily, 18, FontStyleRegular, UnitPixel);
    SolidBrush brush(Color(255, 255, 0));

    g.DrawString(debugText, -1, &font, PointF(10, 30), &brush);

    // 衝突チェックしているタイルを赤枠で表示
    if (debugCheckX >= 0 && debugCheckY >= 0 &&
        debugCheckX < MAP_W && debugCheckY < MAP_H)
    {
        // debugCheckX/Y は内部マップ座標なので、仮想マップに変換
        int worldVirtualX = (debugCheckX + MAP_MARGIN) * TILE;
        int worldVirtualY = (debugCheckY + MAP_MARGIN) * TILE;

        int wx = worldVirtualX - mapOffsetX;
        int wy = worldVirtualY - mapOffsetY;

        Pen pen(Color(255, 0, 0), 3);
        g.DrawRectangle(&pen, wx, wy, TILE, TILE);
    }
#endif

    BitBlt(hdc, 0, 0, screenW, screenH, backDC, 0, 0, SRCCOPY);

    ReleaseDC(hWnd, hdc);
}

//=============================================
// WndProc
//=============================================
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_KEYDOWN:
        if (wParam == VK_UP)    keyUp = true;
        if (wParam == VK_DOWN)  keyDown = true;
        if (wParam == VK_LEFT)  keyLeft = true;
        if (wParam == VK_RIGHT) keyRight = true;
        break;

    case WM_KEYUP:
        if (wParam == VK_UP)    keyUp = false;
        if (wParam == VK_DOWN)  keyDown = false;
        if (wParam == VK_LEFT)  keyLeft = false;
        if (wParam == VK_RIGHT) keyRight = false;
        break;

    case WM_TIMER:
        UpdateInput();
        UpdateScroll();
        UpdateAnimation();
        InvalidateRect(hWnd, NULL, FALSE);
        break;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        DrawGame(hWnd);
        EndPaint(hWnd, &ps);
    }
                 return 0;

    case WM_DESTROY:
        delete imgPlayer;
        DeleteObject(hTileset);
        DeleteDC(hTilesetDC);
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

//=============================================
// WinMain
//=============================================
int APIENTRY wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int) {
    // GDI+
    GdiplusStartupInput gsi;
    GdiplusStartup(&gdiToken, &gsi, NULL);

    
    // JSON 読込
    if (!LoadMapJSON(L"Res/map.json")){
        MessageBox(NULL, L"JSON マップの読み込みに失敗しました。\nInitMap() を使います。", L"Error", MB_OK);
        InitMap(); // fallback
    }

    // スタート位置（内部マップ上のタイル）
    int startTileX = 16;
    int startTileY = 32;

    // プレイヤーのワールド座標に反映（内部マップ座標のまま）
    playerWorldX = startTileX * TILE;
    playerWorldY = startTileY * TILE;

    // 仮想マップ座標系でカメラ初期オフセットを決定
    int VIRTUAL_W = (MAP_W + MAP_MARGIN * 2) * TILE;
    int VIRTUAL_H = (MAP_H + MAP_MARGIN * 2) * TILE;

    int playerVirtualX = playerWorldX + MAP_MARGIN * TILE;
    int playerVirtualY = playerWorldY + MAP_MARGIN * TILE;

    mapOffsetX = playerVirtualX - (screenW / 2 - PLAYER_W / 2);
    mapOffsetY = playerVirtualY - (screenH / 2 - PLAYER_H / 2);

    int maxOffsetX = VIRTUAL_W - screenW;
    int maxOffsetY = VIRTUAL_H - screenH;

    if (mapOffsetX < 0) mapOffsetX = 0;
    if (mapOffsetY < 0) mapOffsetY = 0;
    if (mapOffsetX > maxOffsetX) mapOffsetX = maxOffsetX;
    if (mapOffsetY > maxOffsetY) mapOffsetY = maxOffsetY;

    WNDCLASS wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"MyRPG";
    RegisterClass(&wc);

    RECT rc = { 0,0,screenW,screenH };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);

    HWND hWnd = CreateWindow(
        L"MyRPG", L"RPG",
        WS_OVERLAPPEDWINDOW,
        100, 100,
        rc.right - rc.left,
        rc.bottom - rc.top,
        NULL, NULL, hInst, NULL);

    ShowWindow(hWnd, SW_SHOW);

    HDC hdc = GetDC(hWnd);
    backDC = CreateCompatibleDC(hdc);
    backBuffer = CreateCompatibleBitmap(hdc, screenW, screenH);
    SelectObject(backDC, backBuffer);

    hTileset = (HBITMAP)LoadImage(NULL, L"Res/tileset.bmp",
        IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
    hTilesetDC = CreateCompatibleDC(hdc);
    SelectObject(hTilesetDC, hTileset);

    imgPlayer = new Image(L"./res/player.png"); // ぴぽや　https://pipoya.net/　のデータを使わせいただいてます

    ReleaseDC(hWnd, hdc);

    SetTimer(hWnd, 1, 33, NULL);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    GdiplusShutdown(gdiToken);
}
