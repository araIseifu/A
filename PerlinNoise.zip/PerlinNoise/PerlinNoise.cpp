#include <windows.h>
#include <math.h>
#include <stdlib.h>

#define WIDTH  400
#define HEIGHT 400

// ==== Perlin�m�C�Y�֐��Q ====

// �t�F�[�h�֐�
double fade(double t) {
    return t * t * t * (t * (t * 6 - 15) + 10);
}

// ���`���
double lerp(double a, double b, double t) {
    return a + t * (b - a);
}

// ���z�֐��i2D�Łj
double grad(int hash, double x, double y) {
    int h = hash & 3;
    double u = h < 2 ? x : y;
    double v = h < 2 ? y : x;
    return ((h & 1) ? -u : u) + ((h & 2) ? -2.0 * v : 2.0 * v);
}

// �p�[�~���e�[�V�����e�[�u��
int p[512];
int permutation[256] = {
    151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,
    140,36,103,30,69,142,8,99,37,240,21,10,23,190,6,148,
    247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,
    57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,
    74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,
    60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,
    65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,
    200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,
    52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,
    207,206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,
    119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,
    129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,
    218,246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,
    81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,
    184,84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,
    222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
};

void init_perlin() {
    int i;
    for (i = 0; i < 256; i++)
        p[256 + i] = p[i] = permutation[i];
}

double perlin(double x, double y) {
    int X = (int)floor(x) & 255;
    int Y = (int)floor(y) & 255;
    x -= floor(x);
    y -= floor(y);
    double u = fade(x);
    double v = fade(y);
    int A = p[X] + Y;
    int B = p[X + 1] + Y;

    double res = lerp(
        lerp(grad(p[A], x, y), grad(p[B], x - 1, y), u),
        lerp(grad(p[A + 1], x, y - 1), grad(p[B + 1], x - 1, y - 1), u),
        v
    );

    return (res + 1.0) / 2.0;
}

double octavePerlin(double x, double y, int octaves, double persistence) {
    double total = 0, freq = 1, amp = 1, max = 0;
    for (int i = 0; i < octaves; i++) {
        total += perlin(x * freq, y * freq) * amp;
        max += amp;
        amp *= persistence;
        freq *= 2.0;
    }
    return total / max;
}



// ==== GDI�n�`�`�� ====

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        int x, y;
        for (y = 0; y < HEIGHT; y++) {
            for (x = 0; x < WIDTH; x++) {
                double nx = (double)x / WIDTH * 6.0;
                double ny = (double)y / HEIGHT * 6.0;
                double n = perlin(nx, ny);
                //double n = octavePerlin(nx, ny, 5, 0.5);

                COLORREF color;
                if (n < 0.35)
                    color = RGB(0, 0, 128);      // �C
                else if (n < 0.45)
                    color = RGB(240, 230, 140);  // ��
                else if (n < 0.7)
                    color = RGB(34, 139, 34);    // ����
                else if (n < 0.85)
                    color = RGB(139, 137, 137);  // �R
                else
                    color = RGB(255, 250, 250);  // ��R

                SetPixel(hdc, x, y, color);
            }
        }

        EndPaint(hWnd, &ps);
        break;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wp, lp);
}

// ==== �G���g���|�C���g ====
int WINAPI WinMain(_In_ HINSTANCE hInst, _In_opt_ HINSTANCE hPrev,
        _In_ LPSTR lpCmd, _In_ int nShow) {
    init_perlin();

    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"PerlinMap";         // UNICODE�Ή�
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClass(&wc);

    HWND hWnd = CreateWindow(L"PerlinMap", L"Perlin Noise Terrain",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
        WIDTH + 16, HEIGHT + 39, NULL, NULL, hInst, NULL);

    ShowWindow(hWnd, nShow);
    UpdateWindow(hWnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}
