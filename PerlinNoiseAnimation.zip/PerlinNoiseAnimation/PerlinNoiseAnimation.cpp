#include <windows.h>
#include <math.h>

#define WIDTH  400
#define HEIGHT 300
#define SCALE  0.05  // ���̊��S�łɋ߂��X�P�[��

// -------------------- Perlin Noise --------------------
int p[512];

void initNoise(void) {
    static const int perm[256] = {
        151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,
        140,36,103,30,69,142,8,99,37,240,21,10,23,190,6,148,
        247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,
        57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,
        74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,
        60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,65,
        25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,200,
        196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,52,
        217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,207,
        206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,119,
        248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,129,
        22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,218,
        246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,81,
        51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,184,
        84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,222,
        114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
    };
    for (int i = 0; i < 256; i++) {
        p[i] = perm[i];
        p[256 + i] = perm[i];
    }
}

double fade(double t) { return t * t * t * (t * (t * 6 - 15) + 10); }
double lerp(double a, double b, double t) { return a + t * (b - a); }
double grad(int hash, double x, double y, double z) {
    int h = hash & 15;
    double u = h < 8 ? x : y;
    double v = h < 4 ? y : (h == 12 || h == 14 ? x : z);
    return ((h & 1) ? -u : u) + ((h & 2) ? -v : v);
}

double PerlinNoise(double x, double y, double z) {
    int X = (int)floor(x) & 255;
    int Y = (int)floor(y) & 255;
    int Z = (int)floor(z) & 255;
    x -= floor(x); y -= floor(y); z -= floor(z);
    double u = fade(x), v = fade(y), w = fade(z);
    int A = p[X] + Y, AA = p[A] + Z, AB = p[A + 1] + Z;
    int B = p[X + 1] + Y, BA = p[B] + Z, BB = p[B + 1] + Z;
    double res = lerp(
        lerp(
            lerp(grad(p[AA], x, y, z), grad(p[BA], x - 1, y, z), u),
            lerp(grad(p[AB], x, y - 1, z), grad(p[BB], x - 1, y - 1, z), u),
            v
        ),
        lerp(
            lerp(grad(p[AA + 1], x, y, z - 1), grad(p[BA + 1], x - 1, y, z - 1), u),
            lerp(grad(p[AB + 1], x, y - 1, z - 1), grad(p[BB + 1], x - 1, y - 1, z - 1), u),
            v
        ),
        w
    );
    return (res + 1.0) / 2.0;
}

// -------------------- �t���N�^���m�C�Y�i���K���j --------------------
double fbm(double x, double y, double t) {
    double sum = 0, amp = 1, freq = 1;
    double maxAmp = 0;
    for (int i = 0; i < 4; i++) { // 4�I�N�^�[�u�ɐ���
        sum += PerlinNoise(x * freq, y * freq, t) * amp;
        maxAmp += amp;
        freq *= 2.0;
        amp *= 0.5;
    }
    double val = sum / maxAmp; // 0?1�ɐ��K��
    if (val < 0) val = 0;
    if (val > 1) val = 1;
    return val;
}

// -------------------- �F�⊮ --------------------
COLORREF getColor(double val) {
    if (val < 0.4) {
        double t = val / 0.4;
        return RGB(0, 0, (int)(128 + t * 127)); // �C
    }
    else if (val < 0.55) {
        double t = (val - 0.4) / 0.15;
        int r = (int)(0 * (1 - t) + 20 * t);
        int g = (int)(0 * (1 - t) + 180 * t);
        int b = (int)(128 * (1 - t) + 60 * t);
        return RGB(r, g, b); // ��
    }
    else if (val < 0.7) {
        double t = (val - 0.55) / 0.15;
        int r = (int)(20 * (1 - t) + 100 * t);
        int g = (int)(180 * (1 - t) + 80 * t);
        int b = (int)(60 * (1 - t) + 40 * t);
        return RGB(r, g, b); // �R
    }
    else {
        double t = (val - 0.7) / 0.3;
        int r = (int)(100 * (1 - t) + 255 * t);
        int g = (int)(80 * (1 - t) + 255 * t);
        int b = (int)(40 * (1 - t) + 255 * t);
        return RGB(r, g, b); // ��
    }
}

// -------------------- �o�b�N�o�b�t�@�`�� --------------------
HBITMAP hBitmap = NULL;
HDC hMemDC = NULL;
void* pBits = NULL;

void DrawTerrain(HDC hdc, double t) {
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = WIDTH;
    bmi.bmiHeader.biHeight = -HEIGHT;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    if (!hBitmap) {
        hMemDC = CreateCompatibleDC(hdc);
        hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);
        SelectObject(hMemDC, hBitmap);
    }

    BYTE* buf = (BYTE*)pBits;
    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
            double val = fbm(x * SCALE, y * SCALE, t);
            COLORREF c = getColor(val);
            int idx = (y * WIDTH + x) * 4;
            buf[idx + 0] = GetBValue(c);
            buf[idx + 1] = GetGValue(c);
            buf[idx + 2] = GetRValue(c);
            buf[idx + 3] = 0;
        }
    }
    BitBlt(hdc, 0, 0, WIDTH, HEIGHT, hMemDC, 0, 0, SRCCOPY);
}

// -------------------- Window --------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static double t = 0;
    switch (msg) {
    case WM_CREATE:
        initNoise();
        SetTimer(hwnd, 1, 60, NULL);
        return 0;
    case WM_TIMER:
        t += 0.03;
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        DrawTerrain(hdc, t);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_DESTROY:
        KillTimer(hwnd, 1);
        if (hBitmap) DeleteObject(hBitmap);
        if (hMemDC) DeleteDC(hMemDC);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(_In_ HINSTANCE hInst, _In_opt_ HINSTANCE hPrev,
        _In_ LPSTR lpCmd, _In_ int nCmdShow) {

    WNDCLASS wc = { 0 };
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.lpszClassName = TEXT("PerlinFBM");
    wc.hbrBackground = NULL;
    if (!RegisterClass(&wc)) return -1;

    HWND hwnd = CreateWindow(wc.lpszClassName, TEXT("Perlin Noise Terrain - �C����"),
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
        WIDTH + 16, HEIGHT + 39, NULL, NULL, hInst, NULL);
    if (!hwnd) return -1;

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}
