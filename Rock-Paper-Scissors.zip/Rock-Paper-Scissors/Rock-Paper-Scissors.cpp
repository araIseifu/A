#include <windows.h>
#include <tchar.h>

#define WM_USER_JANKEN (WM_USER + 1)

LRESULT CALLBACK PlayerProc(HWND, UINT, WPARAM, LPARAM);

HWND hPlayer1, hPlayer2;
int choice1 = -1, choice2 = -1; // 0:�O�[, 1:�`���L, 2:�p�[
const TCHAR* handNames[] = { _T("�O�["), _T("�`���L"), _T("�p�[") };

TCHAR msgPlayer1[128] = _T("���Ȃ��̃^�[���ł�");
TCHAR msgPlayer2[128] = _T("����̎��҂��Ă��܂�");

//--------------------------------------------------------------------------------------
// ���s����i1=Player1����, -1=Player2����, 0=�������j
int Judge(int a, int b) {
    if (a == b) return 0;
    if ((a == 0 && b == 1) || (a == 1 && b == 2) || (a == 2 && b == 0))
        return 1;
    return -1;
}

//--------------------------------------------------------------------------------------
LRESULT CALLBACK PlayerProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE:
        CreateWindow(_T("button"), _T("�O�["), WS_CHILD | WS_VISIBLE, 20, 60, 60, 30, hWnd, (HMENU)1, NULL, NULL);
        CreateWindow(_T("button"), _T("�`���L"), WS_CHILD | WS_VISIBLE, 100, 60, 60, 30, hWnd, (HMENU)2, NULL, NULL);
        CreateWindow(_T("button"), _T("�p�["), WS_CHILD | WS_VISIBLE, 180, 60, 60, 30, hWnd, (HMENU)3, NULL, NULL);
        break;

    case WM_COMMAND:
    {
        int id = LOWORD(wParam);
        int choice = id - 1;

        if (hWnd == hPlayer1) {
            choice1 = choice;
            _stprintf_s(msgPlayer1, _T("���Ȃ��� %s ���o���܂���"), handNames[choice]);
            _stprintf_s(msgPlayer2, _T("���肪���I�т܂���"));
            SendMessage(hPlayer2, WM_USER_JANKEN, (WPARAM)choice1, (LPARAM)hWnd);
        }
        else {
            choice2 = choice;
            _stprintf_s(msgPlayer2, _T("���Ȃ��� %s ���o���܂���"), handNames[choice]);
            _stprintf_s(msgPlayer1, _T("���肪���I�т܂���"));
            SendMessage(hPlayer1, WM_USER_JANKEN, (WPARAM)choice2, (LPARAM)hWnd);
        }

        InvalidateRect(hPlayer1, NULL, TRUE);
        InvalidateRect(hPlayer2, NULL, TRUE);
    }
    break;

    case WM_USER_JANKEN:
    {
        HWND from = (HWND)lParam;
        int theirChoice = (int)wParam;

        if (from == hPlayer1)
            choice1 = theirChoice;
        else
            choice2 = theirChoice;

        // �����̎肪�o��������画��
        if (choice1 != -1 && choice2 != -1) {
            int result = Judge(choice1, choice2);

            if (result == 0) {
                _stprintf_s(msgPlayer1, _T("�������I�i%s vs %s�j"), handNames[choice1], handNames[choice2]);
                _stprintf_s(msgPlayer2, _T("�������I�i%s vs %s�j"), handNames[choice2], handNames[choice1]);
            }
            else if (result == 1) {
                _stprintf_s(msgPlayer1, _T("���Ȃ��̏����I�i%s vs %s�j"), handNames[choice1], handNames[choice2]);
                _stprintf_s(msgPlayer2, _T("���Ȃ��̕����I�i%s vs %s�j"), handNames[choice2], handNames[choice1]);
            }
            else {
                _stprintf_s(msgPlayer1, _T("���Ȃ��̕����I�i%s vs %s�j"), handNames[choice1], handNames[choice2]);
                _stprintf_s(msgPlayer2, _T("���Ȃ��̏����I�i%s vs %s�j"), handNames[choice2], handNames[choice1]);
            }

            choice1 = choice2 = -1;
        }

        InvalidateRect(hPlayer1, NULL, TRUE);
        InvalidateRect(hPlayer2, NULL, TRUE);
    }
    break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        RECT rc;
        GetClientRect(hWnd, &rc);

        SetBkMode(hdc, TRANSPARENT);
        DrawText(hdc,
            (hWnd == hPlayer1) ? _T("�v���C���[�P") : _T("�v���C���[�Q"),
            -1, &rc, DT_CENTER | DT_TOP);

        rc.top += 30;
        DrawText(hdc,
            (hWnd == hPlayer1) ? msgPlayer1 : msgPlayer2,
            -1, &rc, DT_CENTER | DT_TOP);
        EndPaint(hWnd, &ps);
    }
    break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

//--------------------------------------------------------------------------------------
int APIENTRY _tWinMain(_In_ HINSTANCE hInst,_In_opt_ HINSTANCE hPrevInstance,_In_ LPTSTR lpCmdLine,_In_ int nCmdShow){

    WNDCLASS wc = {};
    wc.lpfnWndProc = PlayerProc;
    wc.hInstance = hInst;
    wc.lpszClassName = _T("JankenPlayer");
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    RegisterClass(&wc);

    hPlayer1 = CreateWindow(_T("JankenPlayer"), _T("Player1"),
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        100, 100, 300, 160, NULL, NULL, hInst, NULL);

    hPlayer2 = CreateWindow(_T("JankenPlayer"), _T("Player2"),
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        450, 100, 300, 160, NULL, NULL, hInst, NULL);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}
