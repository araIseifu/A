﻿#include <windows.h>
#include "resource.h"

HINSTANCE hInst;

// --- About（ヘルプ）ダイアログ ---
INT_PTR CALLBACK AboutDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM)
{
    switch (msg) {
    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK) {
            EndDialog(hDlg, IDOK);
            return TRUE;
        }
        break;
    }
    return FALSE;
}

// --- メインダイアログ ---
INT_PTR CALLBACK MainDlgProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM)
{
    switch (msg) {
    case WM_INITDIALOG:{
        HICON hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_MYAPP));
        SendMessage(hDlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
        SendMessage(hDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
        return TRUE;
    }
    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDC_BUTTON_HELLO:
            MessageBox(hDlg, TEXT("こんにちは！"), TEXT("メッセージ"), MB_OK);
            return TRUE;

        case IDM_FILE_EXIT:
            DestroyWindow(hDlg);
            PostQuitMessage(0);
            return TRUE;

        case IDM_HELP_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUT), hDlg, AboutDlgProc);
            return TRUE;
        }
        break;

    case WM_CLOSE:
        DestroyWindow(hDlg);
        PostQuitMessage(0);
        return TRUE;
    }
    return FALSE;
}

// --- WinMain ---
int  APIENTRY WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPSTR lpCmdLine, _In_ int nCmdShow) {
       
    hInst = hInstance;

    // メニュー付きダイアログを作成
    HWND hDlg = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, MainDlgProc);
    if (!hDlg) return 0;

    HMENU hMenu = LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MAINMENU));
    SetMenu(hDlg, hMenu);

    ShowWindow(hDlg, SW_SHOW);

    // メッセージループ
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (!IsDialogMessage(hDlg, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    return (int)msg.wParam;
}




