#pragma once

#define IDI_MYAPP           101
#define IDR_MAINMENU        102
#define IDD_MAIN            103
#define IDD_ABOUT           104

#define IDM_FILE_EXIT       40001
#define IDM_HELP_ABOUT      40002

#define IDC_BUTTON_HELLO    1001
