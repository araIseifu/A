//---------------------------------------------- 
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "resource.h"

//----------------------------------------------
#define BUFSIZE 1024
#define STRSIZE 128
#define LEN 8

#define WHITE 'O'           // ��
#define BLACK 'X'           // ��
#define BLANK ' '

#define HUMAN WHITE         // �v���C���[
#define CPU   BLACK         // �R���s���[�^

#define MSG_COMTURN  (WM_USER + 1)
#define MSG_MYTURN   (WM_USER + 2)
#define MSG_FINISHED (WM_USER + 3)

//----------------------------------------------
// �Z�����\����
typedef struct cell {
    int  x;
    int  y;
    char* p_cell;
    int count;
} CELL;

// �t�B�[���h���\����
typedef struct finfo {
    int white;
    int black;
    int blank;
} F_INFO;

//----------------------------------------------
HWND      g_othelloWnd;
HINSTANCE g_hInst;
char      g_player;
char      g_turn;

int g_button[LEN][LEN] = {
{IDC_BUTTON_00,IDC_BUTTON_01,IDC_BUTTON_02,IDC_BUTTON_03,IDC_BUTTON_04,IDC_BUTTON_05,IDC_BUTTON_06,IDC_BUTTON_07},
{IDC_BUTTON_10,IDC_BUTTON_11,IDC_BUTTON_12,IDC_BUTTON_13,IDC_BUTTON_14,IDC_BUTTON_15,IDC_BUTTON_16,IDC_BUTTON_17},
{IDC_BUTTON_20,IDC_BUTTON_21,IDC_BUTTON_22,IDC_BUTTON_23,IDC_BUTTON_24,IDC_BUTTON_25,IDC_BUTTON_26,IDC_BUTTON_27},
{IDC_BUTTON_30,IDC_BUTTON_31,IDC_BUTTON_32,IDC_BUTTON_33,IDC_BUTTON_34,IDC_BUTTON_35,IDC_BUTTON_36,IDC_BUTTON_37},
{IDC_BUTTON_40,IDC_BUTTON_41,IDC_BUTTON_42,IDC_BUTTON_43,IDC_BUTTON_44,IDC_BUTTON_45,IDC_BUTTON_46,IDC_BUTTON_47},
{IDC_BUTTON_50,IDC_BUTTON_51,IDC_BUTTON_52,IDC_BUTTON_53,IDC_BUTTON_54,IDC_BUTTON_55,IDC_BUTTON_56,IDC_BUTTON_57},
{IDC_BUTTON_60,IDC_BUTTON_61,IDC_BUTTON_62,IDC_BUTTON_63,IDC_BUTTON_64,IDC_BUTTON_65,IDC_BUTTON_66,IDC_BUTTON_67},
{IDC_BUTTON_70,IDC_BUTTON_71,IDC_BUTTON_72,IDC_BUTTON_73,IDC_BUTTON_74,IDC_BUTTON_75,IDC_BUTTON_76,IDC_BUTTON_77}
};

//-------------------------------------------------
void updateButton(UINT button, char col) {
    HWND hButton = GetDlgItem(g_othelloWnd, button);
    char s[4];
    sprintf_s(s, "%c", col);
    SendMessage(hButton, WM_SETTEXT, 0, (LPARAM)s);
}

//-------------------------------------------------
void resetAllButton(void) {
    int x, y;
    for (y = 0; y < LEN; y++)
        for (x = 0; x < LEN; x++)
            updateButton(g_button[y][x], BLANK);

    updateButton(g_button[3][4], BLACK);
    updateButton(g_button[4][3], BLACK);
    updateButton(g_button[3][3], WHITE);
    updateButton(g_button[4][4], WHITE);
}

//-------------------------------------------------
void fieldStatus(char f[LEN][LEN], F_INFO* info) {
    info->black = info->white = info->blank = 0;
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            switch (f[y][x]) {
            case WHITE: info->white++; break;
            case BLACK: info->black++; break;
            case BLANK: info->blank++; break;
            default: break;
            }
}

//-------------------------------------------------
void initField(char f[LEN][LEN]) {
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            f[y][x] = BLANK;

    // �����z�u
    f[3][3] = f[4][4] = WHITE;
    f[4][3] = f[3][4] = BLACK;

    resetAllButton();
}

//-------------------------------------------------
char* beInField(char f[LEN][LEN], int y, int x) {
    if (x >= 0 && x < LEN && y >= 0 && y < LEN)
        return &f[y][x];
    return NULL;
}

//-------------------------------------------------
int directCount(int y, int x, int dy, int dx, char c, char f[LEN][LEN], int set) {
    int count = 0;
    x += dx; y += dy;
    char* p;
    while ((p = beInField(f, y, x)) && *p != c) {
        if (*p == BLANK) { count = 0; break; }
        count++;
        x += dx; y += dy;
    }
    if (!p) count = 0;

    if (set && count > 0) {
        x -= dx; y -= dy;
        for (int i = 0; i < count; i++) {
            f[y][x] = c;
            updateButton(g_button[y][x], c);
            x -= dx; y -= dy;
        }
    }
    return count;
}

//-------------------------------------------------
int setPos(int Y, int X, char c, char f[LEN][LEN], int set) {
    int count = 0;
    count += directCount(Y, X, -1, 0, c, f, set);
    count += directCount(Y, X, 1, 0, c, f, set);
    count += directCount(Y, X, 0, -1, c, f, set);
    count += directCount(Y, X, 0, 1, c, f, set);
    count += directCount(Y, X, -1, -1, c, f, set);
    count += directCount(Y, X, -1, 1, c, f, set);
    count += directCount(Y, X, 1, -1, c, f, set);
    count += directCount(Y, X, 1, 1, c, f, set);
    if (set && count > 0) {
        f[Y][X] = c;
        updateButton(g_button[Y][X], c);
    }
    return count;
}

//-------------------------------------------------
int blankCellCount(char f[LEN][LEN]) {
    int blcnt = 0;
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            if (f[y][x] == BLANK) blcnt++;
    return blcnt;
}

//-------------------------------------------------
void availableCellList(char f[LEN][LEN], CELL* list, char player, int* count) {
    *count = 0;
    for (int y = 0; y < LEN; y++) {
        for (int x = 0; x < LEN; x++) {
            if (f[y][x] == BLANK) {
                int flips = setPos(y, x, player, f, 0);
                if (flips > 0) {
                    list[*count].x = x;
                    list[*count].y = y;
                    list[*count].p_cell = &f[y][x];
                    list[*count].count = flips;
                    (*count)++;
                }
            }
        }
    }
}

//-------------------------------------------------
// �]���֐�
int evaluate(char f[LEN][LEN], char player) {
    int scoreTable[LEN][LEN] = {
        {100,-10,10,5,5,10,-10,100},
        {-10,-20,1,1,1,1,-20,-10},
        {10,1,5,2,2,5,1,10},
        {5,1,2,1,1,2,1,5},
        {5,1,2,1,1,2,1,5},
        {10,1,5,2,2,5,1,10},
        {-10,-20,1,1,1,1,-20,-10},
        {100,-10,10,5,5,10,-10,100}
    };

    int score = 0;
    char opponent = (player == BLACK) ? WHITE : BLACK;

    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++) {
            if (f[y][x] == player) score += scoreTable[y][x];
            else if (f[y][x] == opponent) score -= scoreTable[y][x];
        }
    return score;
}

//-------------------------------------------------
// �ȈՃ~�j�}�b�N�X�i�[��2�j
int minimax(char f[LEN][LEN], char player, int depth, bool maximizing) {
    if (depth == 0) return evaluate(f, CPU);

    CELL moves[LEN * LEN];
    int n = 0;
    availableCellList(f, moves, player, &n);
    if (n == 0) return evaluate(f, CPU);

    int bestScore = maximizing ? -10000 : 10000;

    for (int i = 0; i < n; i++) {
        char f2[LEN][LEN];
        memcpy(f2, f, sizeof(f2));
        setPos(moves[i].y, moves[i].x, player, f2, 0); // GUI�X�V�Ȃ�
        int score = minimax(f2, (player == BLACK) ? WHITE : BLACK, depth - 1, !maximizing);
        if (maximizing && score > bestScore) bestScore = score;
        if (!maximizing && score < bestScore) bestScore = score;
    }
    return bestScore;
}

//-------------------------------------------------
// CPU�i��ǂ݂���E�ύX�E�ǉ�: minimax�𗘗p�AGUI�X�V�͍ŏI�肾���j
int cpu(char f[LEN][LEN], char player) {
    CELL bl[LEN * LEN];
    int moveCount = 0;

    // �łĂ�ꏊ��񋓁iGUI�͍X�V���Ȃ��j
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            if (f[y][x] == BLANK) {
                int flips = setPos(y, x, player, f, 0);
                if (flips > 0) {
                    bl[moveCount].x = x;
                    bl[moveCount].y = y;
                    bl[moveCount].count = flips;
                    moveCount++;
                }
            }

    if (moveCount == 0) return 0; // �łĂ�ꏊ�Ȃ�

    int bestScore = -10000;
    CELL best = { 0 };

    // ��ǂ݁i�~�j�}�b�N�X�𗘗p�j
    for (int i = 0; i < moveCount; i++) {
        char f2[LEN][LEN];
        memcpy(f2, f, sizeof(f2));
        setPos(bl[i].y, bl[i].x, player, f2, 0); // GUI�X�V�Ȃ�

        int score = minimax(f2, player,5, true);
        if (score > bestScore) {
            bestScore = score;
            best = bl[i];
        }
    }

    setPos(best.y, best.x, player, f, 1); // GUI�X�V�͍ŏI�肾��
    return bestScore;
}

//-------------------------------------------------
int human(char f[LEN][LEN], char player, int X, int Y, int* check) {
    *check = 0;
    if (f[Y][X] != BLANK) return 0;

    CELL bl[LEN * LEN];
    int n = 0;
    availableCellList(f, bl, player, &n);

    for (int i = 0; i < n; i++) {
        if (bl[i].x == X && bl[i].y == Y) {
            *check = setPos(Y, X, player, f, 1);
            return bl[i].count;
        }
    }
    return 0;
}

//-------------------------------------------------
int caseMyTurn(char f[LEN][LEN], char player) {
    CELL bl[LEN * LEN];
    int n = 0;
    availableCellList(f, bl, player, &n);
    return n;
}

//-------------------------------------------------
LRESULT CALLBACK playOthello(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static char field[LEN][LEN];
    static F_INFO info;
    static int available1 = 0, available2 = 0;
    int X, Y, check;
    char s[STRSIZE];

    switch (msg) {
    case WM_INITDIALOG:
        g_othelloWnd = hWnd;
        g_turn = HUMAN;
        g_player = HUMAN;
        initField(field);
        sprintf_s(s, "���Ȃ��̃^�[���ł��B�΂́i%c�j�ł��B", g_player);
        MessageBox(NULL, s, "Othello", MB_OK);
        PostMessage(g_othelloWnd, MSG_MYTURN, 0, 0);
        return TRUE;

    case WM_COMMAND:
        switch (LOWORD(wParam)) {
        case IDOK:
        case IDCANCEL:
            EndDialog(hWnd, LOWORD(wParam));
            return TRUE;

        default:
            if (g_turn != g_player) return TRUE;

            for (Y = 0; Y < LEN; Y++)
                for (X = 0; X < LEN; X++)
                    if (g_button[Y][X] == LOWORD(wParam)) goto found;
        found:

            available1 = human(field, g_player, X, Y, &check);

            if (!check) { // �ǉ�: �����N���b�N����
                MessageBeep(MB_OK);
                return TRUE;
            }

            g_turn = CPU;
            PostMessage(g_othelloWnd, MSG_COMTURN, 0, 0);
            return TRUE;
        }

    case MSG_MYTURN:
        if (!blankCellCount(field)) { PostMessage(g_othelloWnd, MSG_FINISHED, 0, 0); return TRUE; }
        available1 = caseMyTurn(field, g_player);
        if (!available1) {
            MessageBox(NULL, "�łĂ�ꏊ���Ȃ��̂Ńp�X���܂�", "pass", MB_OK);
            if (!available1 && !available2) PostMessage(g_othelloWnd, MSG_FINISHED, 0, 0);
            else { g_turn = CPU; PostMessage(g_othelloWnd, MSG_COMTURN, 0, 0); }
        }
        return TRUE;

    case MSG_COMTURN:
        available2 = cpu(field, (g_player == WHITE) ? BLACK : WHITE);
        if (!caseMyTurn(field, g_player) && !caseMyTurn(field, (g_player == WHITE) ? BLACK : WHITE))
            PostMessage(g_othelloWnd, MSG_FINISHED, 0, 0);
        else { g_turn = HUMAN; PostMessage(g_othelloWnd, MSG_MYTURN, 0, 0); }
        return TRUE;

    case MSG_FINISHED:
        fieldStatus(field, &info);
        sprintf_s(s, "Retry?  O:%d  X:%d", info.white, info.black);
        if (MessageBox(NULL, s, "Retry?", MB_OKCANCEL) == IDCANCEL)
            EndDialog(g_othelloWnd, 0);
        else
            PostMessage(g_othelloWnd, WM_INITDIALOG, 0, 0);
        return TRUE;
    }

    return FALSE;
}

//-------------------------------------------------
int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow) {
    g_hInst = hInstance;
    DialogBox(g_hInst, MAKEINTRESOURCE(IDD_OTHELLODLG), NULL, (DLGPROC)playOthello);
    return 0;
}
