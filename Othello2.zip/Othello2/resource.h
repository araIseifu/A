//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// Resource.rc �Ŏg�p
//
#define IDI_ICON1                       101
#define IDD_OTHELLODLG                  107

#define IDC_BUTTON_00                   1010
#define IDC_BUTTON_01                   1011
#define IDC_BUTTON_02                   1012
#define IDC_BUTTON_03                   1013
#define IDC_BUTTON_04                   1014
#define IDC_BUTTON_05                   1015
#define IDC_BUTTON_06                   1016
#define IDC_BUTTON_07                   1017
#define IDC_BUTTON_08                   1018
#define IDC_BUTTON_09                   1019
#define IDC_BUTTON_10                   1020

#define IDC_BUTTON_11                   1021
#define IDC_BUTTON_12                   1022
#define IDC_BUTTON_13                   1023
#define IDC_BUTTON_14                   1024
#define IDC_BUTTON_15                   1025
#define IDC_BUTTON_16                   1026
#define IDC_BUTTON_17                   1027
#define IDC_BUTTON_18                   1028
#define IDC_BUTTON_19                   1029
#define IDC_BUTTON_20                   1030

#define IDC_BUTTON_21                   1031
#define IDC_BUTTON_22                   1032
#define IDC_BUTTON_23                   1033
#define IDC_BUTTON_24                   1034
#define IDC_BUTTON_25                   1035
#define IDC_BUTTON_26                   1036
#define IDC_BUTTON_27                   1037
#define IDC_BUTTON_28                   1038
#define IDC_BUTTON_29                   1039
#define IDC_BUTTON_30                   1040

#define IDC_BUTTON_31                   1041
#define IDC_BUTTON_32                   1042
#define IDC_BUTTON_33                   1043
#define IDC_BUTTON_34                   1044
#define IDC_BUTTON_35                   1045
#define IDC_BUTTON_36                   1046
#define IDC_BUTTON_37                   1047
#define IDC_BUTTON_38                   1048
#define IDC_BUTTON_39                   1049
#define IDC_BUTTON_40                   1050

#define IDC_BUTTON_41                   1051
#define IDC_BUTTON_42                   1052
#define IDC_BUTTON_43                   1053
#define IDC_BUTTON_44                   1054
#define IDC_BUTTON_45                   1055
#define IDC_BUTTON_46                   1056
#define IDC_BUTTON_47                   1057
#define IDC_BUTTON_48                   1058
#define IDC_BUTTON_49                   1059
#define IDC_BUTTON_50                   1060

#define IDC_BUTTON_51                   1061
#define IDC_BUTTON_52                   1062
#define IDC_BUTTON_53                   1063
#define IDC_BUTTON_54                   1064
#define IDC_BUTTON_55                   1065
#define IDC_BUTTON_56                   1066
#define IDC_BUTTON_57                   1067
#define IDC_BUTTON_58                   1068
#define IDC_BUTTON_59                   1069
#define IDC_BUTTON_60                   1070

#define IDC_BUTTON_61                   1071
#define IDC_BUTTON_62                   1072
#define IDC_BUTTON_63                   1073
#define IDC_BUTTON_64                   1074
#define IDC_BUTTON_65                   1075
#define IDC_BUTTON_66                   1076
#define IDC_BUTTON_67                   1077
#define IDC_BUTTON_68                   1078
#define IDC_BUTTON_69                   1079
#define IDC_BUTTON_70                   1080

#define IDC_BUTTON_71                   1081
#define IDC_BUTTON_72                   1082
#define IDC_BUTTON_73                   1083
#define IDC_BUTTON_74                   1084
#define IDC_BUTTON_75                   1085
#define IDC_BUTTON_76                   1086
#define IDC_BUTTON_77                   1087

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
