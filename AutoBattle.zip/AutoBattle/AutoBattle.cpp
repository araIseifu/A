#include <windows.h>
#include <process.h>
#include <random>
#include <string>

#define MAX_LOG 20
#define DISPLAY_LOG 10
#define WM_ENDALL   WM_USER + 2     //�@�S���I������Ƃ������[�U�[��`�̃��b�Z�[�W

struct PLAYER {
    HWND hWnd;
    int hp;
    int id;
    std::wstring log[MAX_LOG];
    int logCount;
};

PLAYER player[2];
HANDLE hThread[2];
HANDLE hMutex;
volatile int turn = 0; // ���݂̃^�[���F0=Player1, 1=Player2


//-----------------------------------------------------------------------
// HP�F����
COLORREF GetHPColor(int hp) {
    if (hp > 35) return RGB(0, 255, 0);
    else if (hp > 15) return RGB(255, 255, 0);
    else return RGB(255, 0, 0);
}

//-----------------------------------------------------------------------
// HP�o�[�`��
void DrawHPBar(HDC hdc, RECT rc, int hp, int top, const wchar_t* label) {

    int width = (rc.right - rc.left - 40) * hp / 100;
    HBRUSH hBrush = CreateSolidBrush(GetHPColor(hp));
    RECT bar = { rc.left + 20, top, rc.left + 20 + width, top + 20 };

    FillRect(hdc, &bar, hBrush);
    DeleteObject(hBrush);
    FrameRect(hdc, &bar, (HBRUSH)GetStockObject(BLACK_BRUSH));

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0, 0, 0));
    TextOutW(hdc, 20, top - 20, label, (int)wcslen(label));

    wchar_t buf[16];
    swprintf(buf, 16, L"%d", hp);
    TextOutW(hdc, rc.left + 25 + width, top, buf, (int)wcslen(buf));
}

//-----------------------------------------------------------------------
// ���O�ǉ�
void AddLog(int id, const std::wstring& text) {
    if (player[id].logCount < MAX_LOG) {
        player[id].log[player[id].logCount] = text;
        player[id].logCount++;
    }
    else {
        for (int i = 1; i < MAX_LOG; i++)
            player[id].log[i - 1] = player[id].log[i];
        player[id].log[MAX_LOG - 1] = text;
    }
}

//-----------------------------------------------------------------------
// �_���[�W�K�p�i�^�[���� + Mutex + �Ɨ����� + �N���e�B�J���E�~�X�j
void ApplyDamage(int attacker, int target, std::mt19937& rng) {

    WaitForSingleObject(hMutex, INFINITE);   // �r������J�n

    if (player[attacker].hp <= 0 || player[target].hp <= 0 || turn != attacker) {
        ReleaseMutex(hMutex);
        return;
    }

    // ��{�_���[�W�i3�`10�̗����j�𓾂�irand()�̓X���b�h�Z�[�t�ł͂Ȃ��ׁj
    std::uniform_int_distribution<int> distDamage(3, 10);
    int damage = distDamage(rng);

    // �N���e�B�J������E�~�X����p�̊m�������i1�`100�j
    std::uniform_int_distribution<int> distPercent(1, 100);
    bool isCrit = distPercent(rng) <= 20; // 20%�N���e�B�J���@�@�@//�@���Z�q�̗D�揇�ʂɒ��ӁI
    bool isMiss = distPercent(rng) <= 10; // 10%�~�X

    std::wstring logStr;

    if (isMiss) {  // �~�X�����ꍇ
        damage = 0;
        logStr = L"Player" + std::to_wstring(attacker + 1) + L"�̍U���̓~�X�I";
        AddLog(attacker, logStr);
        AddLog(target, logStr);
    }
    else {   // �~�X���Ȃ�����
        if (isCrit) damage *= 2;    // �N���e�B�J���q�b�g������_���[�W�Q�{

        player[target].hp -= damage; // HP�����炷
        if (player[target].hp < 0) player[target].hp = 0;

        logStr = L"Player" + std::to_wstring(attacker + 1) +
            L"��Player" + std::to_wstring(target + 1) +
            L"��" + std::to_wstring(damage) + L"�_���[�W";
        if (isCrit) logStr += L"�i�N���e�B�J���I�j";
        AddLog(attacker, logStr);

        logStr = L"Player" + std::to_wstring(target + 1) +
            L"��Player" + std::to_wstring(attacker + 1) +
            L"����" + std::to_wstring(damage) + L"�_���[�W���󂯂�";
        if (isCrit) logStr += L"�i�N���e�B�J���I�j";
        AddLog(target, logStr);
    }

    InvalidateRect(player[attacker].hWnd, NULL, TRUE);
    InvalidateRect(player[target].hWnd, NULL, TRUE);

    // ���s����
    if (player[target].hp == 0) {
        std::wstring winStr = L"Player" + std::to_wstring(attacker + 1) + L" WIN!";
        MessageBoxW(player[attacker].hWnd, winStr.c_str(), L"Result", MB_OK);

        std::wstring loseStr = L"Player" + std::to_wstring(target + 1) + L" LOSE!";
        MessageBoxW(player[target].hWnd, loseStr.c_str(), L"Result", MB_OK);

        PostMessage(player[0].hWnd, WM_ENDALL, 0, 0);
        PostMessage(player[1].hWnd, WM_ENDALL, 0, 0);
    }

    turn = target; // �^�[�����

    ReleaseMutex(hMutex);   // �r������I��
}

//-----------------------------------------------------------------------
// �E�B���h�E�v���V�[�W��
LRESULT CALLBACK PlayerProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    int id = (int)(INT_PTR)GetWindowLongPtr(hWnd, GWLP_USERDATA);

    switch (msg) {
    case WM_CREATE:
        SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT*)lParam)->lpCreateParams);
        return 0;

    case WM_ENDALL:
        DestroyWindow(hWnd);
        return 0;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        RECT rc; GetClientRect(hWnd, &rc);
        FillRect(hdc, &rc, (HBRUSH)GetStockObject(WHITE_BRUSH));

        int enemy = (id == 0) ? 1 : 0;
        DrawHPBar(hdc, rc, player[id].hp, 20, L"Your HP");
        DrawHPBar(hdc, rc, player[enemy].hp, 60, L"Enemy HP");

        int y = 100;
        int start = 0;

        if (player[id].logCount > DISPLAY_LOG)
            start = player[id].logCount - DISPLAY_LOG;

        for (int i = start; i < player[id].logCount; i++) {
            TextOutW(hdc, 20, y, player[id].log[i].c_str(), (int)player[id].log[i].length());
            y += 20;
        }

        if (player[id].hp == 0) {
            SetTextColor(hdc, RGB(255, 0, 0));
            TextOutW(hdc, rc.right / 2 - 50, rc.bottom / 2, L"LOSE", 4);
        }

        EndPaint(hWnd, &ps);
    }
                 return 0;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

//-----------------------------------------------------------------------
// �v���C���[�X���b�h
unsigned __stdcall PlayerThread(void* p) {
    int id = (int)(INT_PTR)p;

    std::mt19937 rng((unsigned int)(id + time(NULL)));

    WNDCLASSW wc = { 0 };
    wc.lpfnWndProc = PlayerProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = id == 0 ? L"Player1Class" : L"Player2Class";
    RegisterClassW(&wc);

    HWND hWnd = CreateWindowW(
        wc.lpszClassName,
        id == 0 ? L"Player 1" : L"Player 2",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        id == 0 ? 100 : 800, 200, 600, 500,
        NULL, NULL, wc.hInstance, (LPVOID)(INT_PTR)id
    );

    player[id].hWnd = hWnd;
    player[id].hp = 100;
    player[id].id = id;
    player[id].logCount = 0;

    MSG msg;
    while (1) {
        int enemy = (id == 0) ? 1 : 0;

        if (player[id].hp > 0 && player[enemy].hp > 0 && turn == id) {
            Sleep(300 + rng() % 400);
            ApplyDamage(id, enemy, rng);
        }

        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) return 0;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    return 0;
}


//-----------------------------------------------------------------------
// WinMain
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int) {
    hMutex = CreateMutex(NULL, FALSE, NULL);

    hThread[0] = (HANDLE)_beginthreadex(NULL, 0, PlayerThread, (void*)0, 0, NULL);
    hThread[1] = (HANDLE)_beginthreadex(NULL, 0, PlayerThread, (void*)1, 0, NULL);

    WaitForMultipleObjects(2, hThread, TRUE, INFINITE);

    CloseHandle(hMutex);
    return 0;
}
